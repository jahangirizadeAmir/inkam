<?php
/**
 * Created by PhpStorm.
 * User: amirjahangiri
 * Date: 7/25/18
 * Time: 8:14 PM
 */
session_start();
session_destroy();
header("location:index.php");