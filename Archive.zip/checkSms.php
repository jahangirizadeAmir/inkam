<?php
/**
 * Created by PhpStorm.
 * User: amirjahangiri
 * Date: 7/25/18
 * Time: 6:03 PM
 */
include "inc/my_frame.php";
$D = @smsForati("09166157859");
echo $D;