<?php
/**
 * Created by PhpStorm.
 * User: amirjahangiri
 * Date: 8/21/18
 * Time: 4:00 PM
 */
include "inc/msg.php";

$msg = new msg();

$msg->sendMsg("20180821160232219813","WellCome");